package com.example.manthan.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    Button bt;
   private TextToSpeech tts;
   private SpeechRecognizer scr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt=(Button)findViewById(R.id.button);
        initializeTextToSpeech();
        initializeSpeechRecognizer();

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent it=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                it.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                it.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
                scr.startListening(it);
            }
        });
    }

    private void initializeSpeechRecognizer() {

        if (SpeechRecognizer.isRecognitionAvailable(this))
        {
            scr=SpeechRecognizer.createSpeechRecognizer(this);
            scr.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle bundle) {

                }

                @Override
                public void onBeginningOfSpeech() {

                }

                @Override
                public void onRmsChanged(float v) {

                }

                @Override
                public void onBufferReceived(byte[] bytes) {

                }

                @Override
                public void onEndOfSpeech() {

                }

                @Override
                public void onError(int i) {

                }

                @Override
                public void onResults(Bundle bundle) {

                    List<String> results=bundle.getStringArrayList(
                            SpeechRecognizer.RESULTS_RECOGNITION
                    );
                    processResult(results.get(0));

                }

                @Override
                public void onPartialResults(Bundle bundle) {

                }

                @Override
                public void onEvent(int i, Bundle bundle) {

                }
            });
        }

    }

    private void processResult(String s) {
        s.toLowerCase();
        if (s.indexOf("what")!=-1)
        {
            if (s.indexOf("time")!=-1)
            {
                Calendar c = Calendar.getInstance();

                //Date dt=new Date();
                String time= c.getTime().toString();
                        //DateUtils.formatDateTime(this,dt.getTime(),DateUtils.FORMAT_SHOW_TIME);
                speak(time);
            }
            else if (s.indexOf("is the date now")!=-1)
            {
                Date ddt=new Date();
                String date=DateUtils.formatDateTime(this,ddt.getDate(),DateUtils.FORMAT_SHOW_DATE);
            }

            else if (s.indexOf("is your name")!=-1)
            {
                String name="i am your assistant.";
                speak(name);
            }
        }
        else if (s.indexOf("who")!=-1)
        {
            if (s.indexOf("made you")!=-1)
            {
                speak("manthan made me.");
            }
            else if (s.indexOf("created you")!=-1)
            {
                speak("manthan made me.");
            }
            else  if (s.indexOf("are you")!=-1)
            {
                speak("i am super assistant.");
            }

        }
        else if (s.indexOf("open")!=-1)
        {
            if (s.indexOf("google")!=-1||s.indexOf("internet")!=-1)
            {
                speak("ok here you go");
                Intent in1=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
                startActivity(in1);
            }
        }
        else if (s.indexOf("call")!=-1)
        {
            Intent in2=new Intent("android.intent.action.CALL",Uri.parse("tel:"+"9342667080"));
            startActivity(in2);
        }
        else {
            speak("sorry i could not get the instructions.");
        }
    }

    private void initializeTextToSpeech() {
        tts=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                if (tts.getEngines().size()==0)
                {
                    Toast.makeText(MainActivity.this,"Error it is not possible",Toast.LENGTH_LONG).show();
                    finish();
                }
                else {
                    tts.setLanguage(Locale.US);
                    speak("welcome to assistant application ");
                    //speak("please press the given button to ask something.");
                }

            }
        });
    }

    private void speak(String msg) {
        if (Build.VERSION.SDK_INT>=21)
        {
            tts.speak(msg,TextToSpeech.QUEUE_FLUSH,null,null);
        }
        else {
            tts.speak(msg,TextToSpeech.QUEUE_FLUSH,null);
        }
    }

}
