package com.example.jeevanth.blood2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class Signup extends AppCompatActivity {

    private EditText Firstname;
    private EditText Lastname;
    private EditText Email1;
    private EditText Pass1;
    private EditText Confirmpass;
    private EditText Phone;
    private EditText Bloodgroup;
    private Button Signup1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        Firstname = (EditText)findViewById(R.id.firstname);
        Lastname = (EditText)findViewById(R.id.lastname);

    }
}
